
from nyamuk         import Nyamuk
from event          import *

import nyamuk_const as NC


